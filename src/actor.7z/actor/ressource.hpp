#ifndef DEF_RESSOURCE_HPP
#define DEF_RESSOURCE_HPP
#include "ressource_type.hpp"

class ressource
{
    ressource_type type;
    int ammount;
    //texture handle
};
#endif
