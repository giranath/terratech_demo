#ifndef DEF_TARGET_HANDLE_HPP
#define DEF_TARGET_HANDLE_HPP

#include "base_unit.hpp"
class target_handle
{
    base_unit* target;


};
#endif