#ifndef DEF_RESSOURCE_TYPE_HPP
#define DEF_RESSOURCE_TYPE_HPP

enum class ressource_type
{
    wood,
    food,
    stone,
    gold,
    magic_essence
};

#endif
